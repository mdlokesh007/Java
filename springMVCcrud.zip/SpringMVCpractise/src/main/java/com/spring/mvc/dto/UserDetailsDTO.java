package com.spring.mvc.dto;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.spring.mvc.pojo.UserDetails;

public class UserDetailsDTO {

	private static SessionFactory factory; 

	public static void saveUser(UserDetails user){
        factory = new Configuration().configure().buildSessionFactory();
        Session session = factory.openSession();
        Transaction beginTransaction = session.beginTransaction();
        session.save(user);
        beginTransaction.commit();
        session.close();
	}
	
	public static List<UserDetails> getAllUsers(){
        factory = new Configuration().configure().buildSessionFactory();
        Session session = factory.openSession();
        Transaction beginTransaction = session.beginTransaction();
        Query createQuery = session.createQuery("FROM UserDetails");
        List<UserDetails> list = (List<UserDetails>)createQuery.list();
        beginTransaction.commit();
        session.close();
        return list;
	}
	
	public static void deleteUser(int id) {
		 factory = new Configuration().configure().buildSessionFactory();
	        Session session = factory.openSession();
	        Transaction beginTransaction = session.beginTransaction();
	        Query createQuery = session.createQuery("FROM UserDetails where userId ='"+id+"'");
	        List<UserDetails> list = (List<UserDetails>)createQuery.list();
	        for(UserDetails ud :list) {
	        	session.delete(ud);
	        }
	        beginTransaction.commit();
	        session.close();
		
	}
	public static void updateUser(UserDetails user) {
		 factory = new Configuration().configure().buildSessionFactory();
	        Session session = factory.openSession();
	        Transaction beginTransaction = session.beginTransaction();
	        //UserDetails user1=(UserDetails)session.get(UserDetails.class, user.getUserId());
	        Query createQuery = session.createQuery("FROM UserDetails where name ='"+user.getName()+"'");
	        List<UserDetails> list = (List<UserDetails>)createQuery.list();
	        UserDetails user1=list.get(0);
	        user1.setName(user.getName());
	        user1.setPhone(user.getPhone());
	        user1.setCity(user.getCity());
	        session.update(user1);
	        beginTransaction.commit();
	        session.close();
		
	}

	public static UserDetails getUser(int id) {
		factory = new Configuration().configure().buildSessionFactory();
        Session session = factory.openSession();
        Transaction beginTransaction = session.beginTransaction();
        UserDetails user=(UserDetails)session.get(UserDetails.class, id);
        beginTransaction.commit();
        session.close();
		return user;
	}
	
}
