package com.concretepage.rest;
import java.util.Map;

import org.apache.struts2.rest.DefaultHttpHeaders;
import org.apache.struts2.rest.HttpHeaders;

import com.opensymphony.xwork2.ModelDriven;

public class EmployeeController implements ModelDriven<Object>{
	private static final long serialVersionUID = 1L;
	private String id;
	private Object model;
	private EmployeeRepository employeeRepository = new EmployeeRepository();
	private static Map<String,Employee> map;
	{
		System.out.println("test 11111111111111111111111111111111111");
		map = employeeRepository.findAllEmployee();
	}
	public HttpHeaders index() {
		System.out.println("test 22222222222222222222222222222222222222");
		model = map;
		return new DefaultHttpHeaders("index").disableCaching();
	}
	public String add(){
		System.out.println("test 333333333333333333333333333333333333");
		Integer empId = Integer.parseInt(id);
		Employee emp = new Employee(empId,"Ramesh", "PQR");
		model = emp;
		return "SUCCESS";
	}
	public String getId() {
		System.out.println("test 666666666666666666666666666666");
		return id;
	}
	public void setId(String id) {
		System.out.println("test 5555555555555555555555555555555555555");
		model = employeeRepository.getEmployeeById(id);
		this.id = id;
	}
	public Object getModel() {
		System.out.println("test 444444444444444444444444444444444444444444444444444");
		return model;
	}
} 