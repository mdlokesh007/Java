package com.mkyong.user.action;

import com.opensymphony.xwork2.ModelDriven;

public class testController implements ModelDriven<Object>{

	private String username;
	 
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	// all struts logic here
	public String execute() {

		return "SUCCESS";

	}
	
	public String fetchThis(){
		for(int i=0;i<10;i++){System.out.println("fetchThis");}
		return "SUCCESS";

	}
	
	@Override
	public Object getModel() {
		// TODO Auto-generated method stub
		return null;
	}
}